import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule, HttpClient} from '@angular/common/http';
import { NgbModule, NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

import { environment } from '../environments/environment';
import { ExperimentComponent } from './experiment/experiment.component';
import { ExperimentInfoComponent } from './experiment/experiment-info/experiment-info.component';
import { ExperimentListComponent } from './experiment/experiment-list/experiment-list.component';
import { HeaderComponent } from './shared/header/header.component';
import { ExperimentNavComponent } from './experiment-nav/experiment-nav.component';
import { PageNotFoundComponent } from './shared/page-not-found/page-not-found.component';
import { AccessDeniedComponent } from './shared/access-denied/access-denied.component';
import { ExperimentService } from './service/experiment.service';
import { ExperimentAddComponent } from './experiment-nav/experiment-add/experiment-add.component';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    ExperimentNavComponent,
    ExperimentComponent,
    ExperimentInfoComponent,
    ExperimentListComponent,
    PageNotFoundComponent,
    AccessDeniedComponent,
    ExperimentAddComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    NgbModule
  ],
  providers: [ExperimentService,
    NgbActiveModal],
  bootstrap: [AppComponent],
  entryComponents: []
})
export class AppModule { }
