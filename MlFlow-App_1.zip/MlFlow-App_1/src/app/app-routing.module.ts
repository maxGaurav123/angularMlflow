import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ExperimentComponent } from './experiment/experiment.component';
import { PageNotFoundComponent } from './shared/page-not-found/page-not-found.component';
import { ExperimentInfoComponent } from './experiment/experiment-info/experiment-info.component';

const routes: Routes = [
  {
    path: 'experiment/:id', component: ExperimentInfoComponent
  },
  {
    path: '**', component: PageNotFoundComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
