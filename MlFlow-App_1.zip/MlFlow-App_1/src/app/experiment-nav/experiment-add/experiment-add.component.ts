import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { NgbModal, NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { ExperimentService } from 'src/app/service/experiment.service';
import { Router } from '@angular/router';
import { ComponentCommunicationService } from 'src/app/service/component-communication.service';

@Component({
  selector: 'app-experiment-add',
  templateUrl: './experiment-add.component.html',
  styleUrls: ['./experiment-add.component.scss']
})
export class ExperimentAddComponent implements OnInit {

  experimentName: string;
  artifiactLocation: string;
  @ViewChild('addExperiment') experimentAddPopUp: ElementRef;
  constructor(private modalService: NgbModal, private activeModal: NgbActiveModal,
              private experimentService: ExperimentService, private router: Router,
              private compCommunication: ComponentCommunicationService) { }

  ngOnInit() {
  }

  OpenAddExperimentPopUp() {
    // Open modal pop-up
    this.experimentName = '';
    this.artifiactLocation = '';
    this.modalService.open(this.experimentAddPopUp, { size: 'lg', centered: true, backdrop: 'static', keyboard: false});
  }

  closePopup() {
    this.modalService.dismissAll();
  }

  submitExperimentAdd() {
    this.experimentService.AddExperiment(this.experimentName, this.artifiactLocation)
      .subscribe((x: any) => {
        if (x) {
          this.compCommunication.triggerExperimentsListRefresh();
          const path = '/' + 'experiment/' + x.experiment_id;

          this.modalService.dismissAll();
          this.router.navigate([path]);
        }
      });
  }

}
