import { Component, OnInit, OnDestroy } from '@angular/core';
import { ExperimentService } from '../service/experiment.service';
import { ComponentCommunicationService } from '../service/component-communication.service';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-experiment-nav',
  templateUrl: './experiment-nav.component.html',
  styleUrls: ['./experiment-nav.component.scss']
})
export class ExperimentNavComponent implements OnInit, OnDestroy {

  expirements: any;
  selectedExperiment = -1;
  subExperimentList: Subscription;
  subCompCommunication: Subscription;
  // tslint:disable-next-line:variable-name
  subCompCommunication_2: Subscription;
  constructor(private experimentService: ExperimentService, private compCommunicationService: ComponentCommunicationService) { }

  ngOnInit() {
    this.GetExperiments();
    this.SubscribeToChangedExperimentId();
    this.SubscribeToRefreshRequired();
  }

  ngOnDestroy() {
    if (this.subExperimentList) {
      this.subExperimentList.unsubscribe();
    }
    if (this.subCompCommunication) {
      this.subCompCommunication.unsubscribe();
    }
    if (this.subCompCommunication_2) {
      this.subCompCommunication_2.unsubscribe();
    }
  }

  GetExperiments() {
    this.subExperimentList = this.experimentService.GetExperimentsList()
      .subscribe(exp => {
        if (exp && exp.experiments) {
          // Sort the list in ascending order by Name.
          const exps = exp.experiments.sort(function (a, b) {
            const nameA = a.name.toUpperCase(); // ignore upper and lowercase
            const nameB = b.name.toUpperCase(); // ignore upper and lowercase
            if (nameA < nameB) {
              return -1;
            }
            if (nameA > nameB) {
              return 1;
            }
            // names must be equal
            return 0;
          });

          this.expirements = exps;
          if (!isNaN(this.expirements[0].experiment_id)) {
            this.selectedExperiment = this.expirements[0].experiment_id;
          } else {
            this.selectedExperiment = undefined;
          }
        }
      });
  }

  UpdateSelectedExperiment(expId: any) {
    this.selectedExperiment = expId;
  }

  SubscribeToChangedExperimentId() {
    this.subCompCommunication = this.compCommunicationService.subscribeToExperimentId()
      .subscribe(x => {
        if (!isNaN(x)) {
          this.selectedExperiment = x;
        }
      });
  }

  SubscribeToRefreshRequired() {
    this.subCompCommunication_2 = this.compCommunicationService.subscribeToExperimentsRefershTrigger()
      .subscribe(x => {
        if (x) {
          this.GetExperiments();
        }
      });
  }
}
