import { Injectable } from '@angular/core';
import { Subject, Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ComponentCommunicationService {

  private experimentId: Subject<number> = new Subject<number>();
  private triggerExperimentRefresh: Subject<boolean> = new Subject<boolean>();
  constructor() { }

  subscribeToExperimentId(): Observable<any> {
    return this.experimentId.asObservable();
  }

  pushCurrentExperimentId(expId: any) {
    this.experimentId.next(expId);
  }

  subscribeToExperimentsRefershTrigger(): Observable<any> {
    return this.triggerExperimentRefresh.asObservable();
  }

  triggerExperimentsListRefresh() {
    this.triggerExperimentRefresh.next(true);
  }
}
