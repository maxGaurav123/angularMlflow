import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { RunSearchInputPayload } from '../model/RunSearchInputPayload';

@Injectable({
  providedIn: 'root'
})
export class ExperimentService {

  // tslint:disable-next-line:variable-name
  constructor(private _http: HttpClient) { }

  GetExperimentsList(): Observable<any> {
    return this._http.get<any>(`${environment.mlFlowApi}/experiments/list`);
  }

  GetExperimentDetails(expId: any): Observable<any> {
    return this._http.get<any>(`${environment.mlFlowApi}/experiments/get`, {
      params: {
        experiment_id: expId
      }
    });
  }

  GetRunsForAnExperiment(searchInputPayload: RunSearchInputPayload) {
    // {"experiment_ids":[0],"anded_expressions":[],"run_view_type":"ACTIVE_ONLY"}
    // tslint:disable-next-line:max-line-length
    const payload = { 'experiment_ids': searchInputPayload.experiment_ids, 'anded_expressions': searchInputPayload.anded_expressions, 'run_view_type': 'ACTIVE_ONLY' };
    return this._http.post<any>(`${environment.mlFlowApi}/runs/search`, payload);
  }

  AddExperiment(expname: string, artifactLocation: string) {
    const params = { 'name': expname, 'artifact_location': artifactLocation };
    return this._http.post(`${environment.mlFlowApi}/experiments/create`, params);
  }

  private handleError(err: HttpErrorResponse) {

  }
}
