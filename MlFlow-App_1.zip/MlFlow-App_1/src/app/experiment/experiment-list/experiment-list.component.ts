import { Component, OnInit, OnDestroy, OnChanges, Input } from '@angular/core';
import { RunSearchInputPayload } from 'src/app/model/RunSearchInputPayload';
import { ExperimentService } from 'src/app/service/experiment.service';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-experiment-list',
  templateUrl: './experiment-list.component.html',
  styleUrls: ['./experiment-list.component.scss']
})
export class ExperimentListComponent implements OnInit, OnDestroy, OnChanges {

  searchedRunsData: any;
  subSearchedRuns: Subscription;
  @Input() searchInputPayload: RunSearchInputPayload;
  @Input() selectedExperimentId: any;
  isMetricsAvailable: boolean;
  isParametersAvailable: boolean;

  constructor(private experimentService: ExperimentService) { }

  ngOnInit() {
    this.searchInputPayload = new RunSearchInputPayload();
    this.searchInputPayload.experiment_ids = [this.selectedExperimentId];

    this.GetRunsListForExperiments(this.searchInputPayload);
  }
  ngOnChanges() {
    if (!isNaN(this.selectedExperimentId) && this.searchInputPayload) {
      this.searchInputPayload.experiment_ids = [this.selectedExperimentId];
      this.GetRunsListForExperiments(this.searchInputPayload);
    }
  }
  ngOnDestroy() {
    if (this.subSearchedRuns) {
      this.subSearchedRuns.unsubscribe();
    }
  }

  GetRunsListForExperiments(searchInputPayload: RunSearchInputPayload) {
    this.subSearchedRuns = this.experimentService.GetRunsForAnExperiment(searchInputPayload)
      .subscribe(x => {
        if (x && x.runs) {
          this.searchedRunsData = x.runs;

          // Check if Parameters are available in Runs Data.
          if (this.searchedRunsData.length > 0 && this.searchedRunsData[0].data.params) {
            this.isParametersAvailable = true;
          } else {
            this.isParametersAvailable = false;
          }

          // Check if Metrics are available in Runs Data.
          if (this.searchedRunsData.length > 0 && this.searchedRunsData[0].data.metrics) {
            this.isMetricsAvailable = true;
          } else {
            this.isMetricsAvailable = false;
          }
        } else {
          this.searchedRunsData = undefined;
          this.isMetricsAvailable = false;
          this.isParametersAvailable = false;
        }
      });
  }

  getDateInFormat(dateTimestirng: any): string {
    if (dateTimestirng && dateTimestirng.trim().length > 0 && !isNaN(dateTimestirng)) {
      const d = new Date(+dateTimestirng);
      const dformat = [d.getFullYear(),
                      d.getMonth() + 1,
                      d.getDate(),
                      ].join('-') + ' ' +
                        [d.getHours(),
                        d.getMinutes(),
                        d.getSeconds()].join(':');
      return dformat;
    } else {
      return '';
    }
  }

}
