import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRouteSnapshot, ActivatedRoute } from '@angular/router';
import { ExperimentService } from 'src/app/service/experiment.service';
import { ComponentCommunicationService } from 'src/app/service/component-communication.service';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-experiment-info',
  templateUrl: './experiment-info.component.html',
  styleUrls: ['./experiment-info.component.scss']
})
export class ExperimentInfoComponent implements OnInit, OnDestroy {

  selectedExperimentId: any;
  experimentDetails = {};
  subExperimentDetails: Subscription;

  constructor(private _activatedRoute: ActivatedRoute, private _experimentService: ExperimentService,
    private compCommunicationService: ComponentCommunicationService) { }

  ngOnInit() {
    this._activatedRoute.params
      .subscribe(x => {
        this.selectedExperimentId = x.id;
        this.GetExperimentDetails(x.id);

      });
  }

  ngOnDestroy() {
    if (this.subExperimentDetails) {
      this.subExperimentDetails.unsubscribe();
    }
  }

  GetExperimentDetails(expId: any) {
    this.subExperimentDetails = this._experimentService.GetExperimentDetails(expId)
      .subscribe(x => {
        if (x && x.experiment) {
          this.experimentDetails = x;
        } else {
          this.experimentDetails = undefined;
        }
        this.compCommunicationService.pushCurrentExperimentId(this.selectedExperimentId);
      });
  }

}
