export class RunSearchInputPayload {
    // tslint:disable-next-line:variable-name
    public experiment_ids: Array<number>;
    // tslint:disable-next-line:variable-name
    public anded_expressions: [];
    // tslint:disable-next-line:variable-name
    public run_view_type: string;

    constructor() {
        this.experiment_ids = new Array<number>();
        this.anded_expressions = [];
        this.run_view_type = '';
    }
  }
