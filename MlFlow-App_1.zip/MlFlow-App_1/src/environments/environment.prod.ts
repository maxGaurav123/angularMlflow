export const environment = {
  production: true,
  mlFlowApi: 'http://172.17.0.5:5000/api/2.0/preview/mlflow/'
};
